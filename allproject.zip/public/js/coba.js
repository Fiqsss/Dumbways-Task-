for (let i = 0; i < 10; i++) {
  console.log(i);
}

const coba = document.querySelector(".coba");
coba.innerHTML = "halo";