// sychronous
// console.log("start");
// function fetchData() {
//   const data = " data fetched";
//   return data ;
// }
// const result = fetchData();
// console.log(result);
// console.log("end");

//const fetchData2 = new Promise((resolve, reject) => {
//    setTimeout(() => {
//        resolve('Hello World')
//    }, 1000)
//    console.log('test');
//})
//
//fetchData2.then(data => console.log(data)).catch(err => console.log(err))
// const fetchData = new Promise((resolve, reject) => {
//     setTimeout(() => {
//         resolve('Hello World')
//     }, 1000)
// })

// fetchData
//     .then(data => console.log(data))
//     .catch(err => console.log(err))
